# KNUST Hive — Professional Audit & Release Plan

## Current baseline
The supplied project is a Flutter application using Riverpod, GoRouter, Supabase, and Hive local storage. Existing feature areas include authentication, a student dashboard, campus feed, shuttle tracker, skills, profiles, and a realtime 1:1 chat implementation.

## High-priority findings

1. **Database security coverage was incomplete.** RLS was enabled for only a subset of public tables. The updated `supabase/schema.sql` adds RLS policies for campus stops, community membership, RSVPs, skill progress, timetable/GPA records, marketplace listings, past-question metadata, and mentorship records. It also protects the student-ID verification table while keeping the signup trigger functional.
2. **Storage security is a separate requirement.** The `past_questions.file_url` field points to Supabase Storage; the actual bucket needs its own access policies before uploads should be treated as private or production-ready.
3. **Academic and social features are not all implemented in the UI.** The README identifies communities, mentorship, timetable/GPA, marketplace, past questions, SOS, and moderation as planned/scaffolded areas. Do not advertise these as live until the screens, backend flows, and tests are complete.
4. **Deployment validation remains necessary.** This environment does not have the Flutter/Dart SDK or a configured Supabase project, so a real `flutter analyze`, device build, SQL execution, and end-to-end test have not been performed.
5. **Production readiness needs real-world checks.** Verify student-ID import process, account recovery, profile update rules, abuse reporting, moderation workflow, privacy notice, data retention, crash reporting, and store signing before public launch.

## Recommended execution order

### Phase 1 — Stabilize
- Run `flutter pub get` and `flutter analyze` on a machine with Flutter installed.
- Apply the SQL schema to a staging Supabase project, then test each RLS policy using two different student accounts and an unauthenticated session.
- Confirm auth redirects, chat creation, message sending, realtime updates, and sign-out.
- Add widget/unit tests for auth state, dashboard empty/error states, feed ownership, and chat permissions.

### Phase 2 — Core student value
- Finish Academics: timetable CRUD, overlap detection, course list, GPA calculator, exam/assignment reminders.
- Finish Feed: comments/reactions, report/block, moderation and pagination.
- Finish Chat: conversation states, unread counts, message pagination, block/report controls, and notification strategy.

### Phase 3 — Campus services
- Marketplace with image upload, seller contact, report listing, and safe transaction guidance.
- Communities with member roles, moderation, and join/leave flows.
- Past questions with upload permissions, file metadata, search, and takedown process.

### Phase 4 — Launch
- Add privacy policy and terms, contact/support path, analytics/crash reporting, branded icon/splash, release signing, and a closed beta checklist.
- Test on lower-end Android devices and unreliable mobile data before a public rollout.

## Important safety note
The new SQL policies are a security baseline, not a substitute for staging tests. The application must be tested against the exact Supabase grants, storage bucket settings, and current client queries before deploying to real student accounts.
