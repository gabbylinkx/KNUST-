-- ============================================================
-- KNUST Hive — Supabase schema
-- Run in the Supabase SQL editor, top to bottom, on a fresh project.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- Verified student IDs (uploaded each semester by registrar) ----------
create table verified_student_ids (
  student_id text primary key,
  full_name text,
  faculty text,
  imported_at timestamptz default now()
);

-- ---------- Profiles (extends auth.users) ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  student_id text not null unique,
  display_name text not null,
  faculty text,
  department text,
  year_group int,
  interests text[] default '{}',
  avatar_url text,
  created_at timestamptz default now()
);

-- Reject sign-ups whose student_id isn't in the registrar's verified list.
create or replace function check_student_id()
returns trigger as $$
begin
  if not exists (select 1 from verified_student_ids where student_id = new.student_id) then
    raise exception 'Student ID % is not recognized. Contact IT support if this is an error.', new.student_id;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_check_student_id
  before insert on profiles
  for each row execute function check_student_id();

-- ---------- Stops (shuttle) ----------
create table stops (
  id text primary key,
  name text not null,
  route text not null check (route in ('green', 'gold')),
  lat double precision,   -- nullable until GPS survey is done
  lng double precision,
  is_hub boolean default false
);

-- ---------- Shuttle sightings (crowdsourced) ----------
create table shuttle_reports (
  id uuid primary key default uuid_generate_v4(),
  stop_id text not null references stops(id),
  route text not null check (route in ('green', 'gold')),
  reported_by uuid not null references profiles(id),
  created_at timestamptz default now()
);
create index on shuttle_reports (created_at desc);

-- ---------- Ride board ----------
create table ride_posts (
  id uuid primary key default uuid_generate_v4(),
  type text not null check (type in ('need', 'offer')),
  from_stop_id text not null references stops(id),
  to_stop_id text not null references stops(id),
  time_label text not null,
  note text,
  posted_by uuid not null references profiles(id),
  created_at timestamptz default now()
);

-- ---------- Campus feed ----------
create table feed_posts (
  id uuid primary key default uuid_generate_v4(),
  category text not null check (category in ('event', 'lostFound', 'shoutout', 'studyGroup')),
  text text not null,
  posted_by uuid not null references profiles(id),
  rsvp_count int default 0,
  created_at timestamptz default now()
);

create table event_rsvps (
  post_id uuid references feed_posts(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (post_id, user_id)
);

-- ---------- Communities ----------
create table communities (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  description text
);

create table community_members (
  community_id uuid references communities(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (community_id, user_id)
);

-- ---------- Chat ----------
create table chats (
  id uuid primary key default uuid_generate_v4(),
  is_group boolean default false,
  is_anonymous_wall boolean default false, -- confession wall
  name text,
  created_at timestamptz default now()
);

create table chat_members (
  chat_id uuid references chats(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (chat_id, user_id)
);

create table messages (
  id uuid primary key default uuid_generate_v4(),
  chat_id uuid references chats(id) on delete cascade,
  sender_id uuid references profiles(id),
  text text not null,
  flagged boolean default false, -- set by moderation function before showing on wall
  created_at timestamptz default now()
);
create index on messages (chat_id, created_at);

-- ---------- Skills ----------
create table skill_paths (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  tag text,
  description text,
  resource_url text
);

create table user_skill_progress (
  user_id uuid references profiles(id) on delete cascade,
  skill_id uuid references skill_paths(id) on delete cascade,
  status text default 'started' check (status in ('started', 'completed')),
  updated_at timestamptz default now(),
  primary key (user_id, skill_id)
);

create table mentorships (
  mentor_id uuid references profiles(id),
  mentee_id uuid references profiles(id),
  status text default 'pending' check (status in ('pending', 'active', 'ended')),
  created_at timestamptz default now(),
  primary key (mentor_id, mentee_id)
);

-- ---------- Academics ----------
create table timetable_entries (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  course_name text not null,
  day_of_week int not null check (day_of_week between 0 and 6),
  start_time time not null,
  end_time time not null,
  room text,
  -- prevents two entries for the same user overlapping in time
  exclude using gist (
    user_id with =,
    day_of_week with =,
    tsrange('2000-01-01'::date + start_time, '2000-01-01'::date + end_time) with &&
  )
);

create table gpa_records (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references profiles(id) on delete cascade,
  course_code text not null,
  credit_hours numeric not null,
  grade text not null,
  semester text not null
);

-- ---------- Marketplace ----------
create table marketplace_listings (
  id uuid primary key default uuid_generate_v4(),
  seller_id uuid references profiles(id),
  title text not null,
  price numeric,
  description text,
  image_url text,
  status text default 'available' check (status in ('available', 'sold')),
  created_at timestamptz default now()
);

-- ---------- Past questions repository ----------
create table past_questions (
  id uuid primary key default uuid_generate_v4(),
  course_code text not null,
  year int,
  file_url text not null, -- Supabase Storage path
  uploaded_by uuid references profiles(id)
);

-- ============================================================
-- Row Level Security
-- ============================================================
alter table profiles enable row level security;
alter table shuttle_reports enable row level security;
alter table ride_posts enable row level security;
alter table feed_posts enable row level security;
alter table messages enable row level security;
alter table chat_members enable row level security;

create policy "profiles are viewable by any signed-in student"
  on profiles for select using (auth.role() = 'authenticated');
create policy "users manage their own profile"
  on profiles for update using (auth.uid() = id);

create policy "reports viewable by all, insertable by owner"
  on shuttle_reports for select using (true);
create policy "reports insertable by signed-in students"
  on shuttle_reports for insert with check (auth.uid() = reported_by);

create policy "ride posts viewable by all"
  on ride_posts for select using (true);
create policy "ride posts insertable by owner"
  on ride_posts for insert with check (auth.uid() = posted_by);
create policy "ride posts deletable by owner"
  on ride_posts for delete using (auth.uid() = posted_by);

create policy "feed viewable by all"
  on feed_posts for select using (true);
create policy "feed insertable by owner"
  on feed_posts for insert with check (auth.uid() = posted_by);
create policy "feed deletable by owner"
  on feed_posts for delete using (auth.uid() = posted_by);

create policy "messages viewable only by chat members"
  on messages for select using (
    exists (select 1 from chat_members cm where cm.chat_id = messages.chat_id and cm.user_id = auth.uid())
  );
create policy "messages insertable only by chat members"
  on messages for insert with check (
    exists (select 1 from chat_members cm where cm.chat_id = messages.chat_id and cm.user_id = auth.uid())
  );

-- ============================================================
-- Enable Realtime on the tables the app streams from
-- ============================================================
alter publication supabase_realtime add table shuttle_reports;
alter publication supabase_realtime add table ride_posts;
alter publication supabase_realtime add table feed_posts;
alter publication supabase_realtime add table messages;

-- ============================================================
-- Seed: campus stops
-- ============================================================
insert into stops (id, name, route, is_hub) values
  ('g0', 'Main Gate', 'green', false),
  ('g1', 'Republic Hall', 'green', false),
  ('g2', 'Katanga', 'green', false),
  ('hub', 'Commercial Area', 'green', true),
  ('g3', 'Engineering', 'green', false),
  ('g4', 'Business School', 'green', false),
  ('g5', 'Conti Campus', 'green', false),
  ('y0', 'Bomso Gate', 'gold', false),
  ('y1', 'Ayeduase Gate', 'gold', false),
  ('y2', 'Unity Hall', 'gold', false),
  ('y3', 'Africa Hall', 'gold', false),
  ('y4', 'Queens Hall', 'gold', false),
  ('y5', 'Univ. Hospital', 'gold', false)
on conflict (id) do nothing;


-- ============================================================
-- Chat hardening + direct-chat RPC
-- ============================================================
alter table chats enable row level security;

create policy "chat members can view their chats"
  on chats for select using (
    exists (
      select 1
      from chat_members cm
      where cm.chat_id = chats.id
        and cm.user_id = auth.uid()
    )
  );

create policy "users can view their own memberships"
  on chat_members for select using (user_id = auth.uid());

-- Keep sender identity bound to the authenticated account.
drop policy if exists "messages insertable only by chat members" on messages;
create policy "messages insertable only by chat members"
  on messages for insert with check (
    sender_id = auth.uid()
    and exists (
      select 1
      from chat_members cm
      where cm.chat_id = messages.chat_id
        and cm.user_id = auth.uid()
    )
  );

-- Creates (or reuses) a private 1:1 chat and adds both participants.
-- SECURITY DEFINER is intentional: clients never get direct write access
-- to chat membership; this function performs the controlled membership change.
create or replace function create_direct_chat(other_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  me uuid := auth.uid();
  existing_chat uuid;
  new_chat uuid;
begin
  if me is null then
    raise exception 'You must be signed in.';
  end if;

  if other_user_id is null or other_user_id = me then
    raise exception 'Choose another student.';
  end if;

  if not exists (select 1 from profiles where id = other_user_id) then
    raise exception 'Student not found.';
  end if;

  select cm1.chat_id
    into existing_chat
  from chat_members cm1
  join chat_members cm2 on cm2.chat_id = cm1.chat_id
  join chats c on c.id = cm1.chat_id
  where cm1.user_id = me
    and cm2.user_id = other_user_id
    and c.is_group = false
    and c.is_anonymous_wall = false
  limit 1;

  if existing_chat is not null then
    return existing_chat;
  end if;

  insert into chats (is_group, is_anonymous_wall)
  values (false, false)
  returning id into new_chat;

  insert into chat_members (chat_id, user_id)
  values (new_chat, me), (new_chat, other_user_id);

  return new_chat;
end;
$$;

revoke all on function create_direct_chat(uuid) from public;
grant execute on function create_direct_chat(uuid) to authenticated;

-- ============================================================
-- Production security baseline for tables used by current and
-- planned features. Apply after the base schema above.
-- ============================================================

-- Student ID verification data must never be readable through the public API.
-- SECURITY DEFINER allows the signup trigger to validate IDs without exposing
-- the table to client roles. The fixed search_path prevents object shadowing.
alter table verified_student_ids enable row level security;
create or replace function check_student_id()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.verified_student_ids where student_id = new.student_id) then
    raise exception 'Student ID is not recognized. Contact IT support if this is an error.';
  end if;
  return new;
end;
$$;

-- Campus stops are reference data available to signed-in students.
alter table stops enable row level security;
drop policy if exists "signed-in students can view stops" on stops;
create policy "signed-in students can view stops" on stops for select to authenticated using (true);

-- Community directory and memberships.
alter table communities enable row level security;
alter table community_members enable row level security;
drop policy if exists "signed-in students can view communities" on communities;
create policy "signed-in students can view communities" on communities for select to authenticated using (true);
drop policy if exists "members can view community memberships" on community_members;
create policy "members can view community memberships" on community_members for select to authenticated using (user_id = auth.uid());
drop policy if exists "students can join as themselves" on community_members;
create policy "students can join as themselves" on community_members for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "students can leave communities" on community_members;
create policy "students can leave communities" on community_members for delete to authenticated using (user_id = auth.uid());

-- Event RSVPs are owned by the student who creates them.
alter table event_rsvps enable row level security;
drop policy if exists "signed-in students can view event RSVPs" on event_rsvps;
create policy "signed-in students can view event RSVPs" on event_rsvps for select to authenticated using (true);
drop policy if exists "students can RSVP as themselves" on event_rsvps;
create policy "students can RSVP as themselves" on event_rsvps for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "students can cancel their own RSVP" on event_rsvps;
create policy "students can cancel their own RSVP" on event_rsvps for delete to authenticated using (user_id = auth.uid());

-- Skill catalogue is readable; personal progress is private.
alter table skill_paths enable row level security;
alter table user_skill_progress enable row level security;
drop policy if exists "signed-in students can view skill paths" on skill_paths;
create policy "signed-in students can view skill paths" on skill_paths for select to authenticated using (true);
drop policy if exists "students manage their own skill progress" on user_skill_progress;
create policy "students manage their own skill progress" on user_skill_progress for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Academic records are private to each student.
alter table timetable_entries enable row level security;
alter table gpa_records enable row level security;
drop policy if exists "students manage their own timetable" on timetable_entries;
create policy "students manage their own timetable" on timetable_entries for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "students manage their own GPA records" on gpa_records;
create policy "students manage their own GPA records" on gpa_records for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Marketplace listings are discoverable by signed-in students; sellers own edits.
alter table marketplace_listings enable row level security;
drop policy if exists "signed-in students can view marketplace listings" on marketplace_listings;
create policy "signed-in students can view marketplace listings" on marketplace_listings for select to authenticated using (true);
drop policy if exists "sellers manage their own listings" on marketplace_listings;
create policy "sellers manage their own listings" on marketplace_listings for all to authenticated using (seller_id = auth.uid()) with check (seller_id = auth.uid());

-- Past-question metadata is discoverable; upload ownership is enforced here.
-- Storage bucket policies must separately protect the actual uploaded files.
alter table past_questions enable row level security;
drop policy if exists "signed-in students can view past questions" on past_questions;
create policy "signed-in students can view past questions" on past_questions for select to authenticated using (true);
drop policy if exists "students manage their own past questions" on past_questions;
create policy "students manage their own past questions" on past_questions for all to authenticated using (uploaded_by = auth.uid()) with check (uploaded_by = auth.uid());

-- Mentorship requests are visible only to their participants.
alter table mentorships enable row level security;
drop policy if exists "participants can view mentorships" on mentorships;
create policy "participants can view mentorships" on mentorships for select to authenticated using (mentor_id = auth.uid() or mentee_id = auth.uid());
drop policy if exists "students can request mentorship" on mentorships;
create policy "students can request mentorship" on mentorships for insert to authenticated with check (mentee_id = auth.uid() and mentor_id <> auth.uid());
drop policy if exists "participants can update mentorship status" on mentorships;
create policy "participants can update mentorship status" on mentorships for update to authenticated using (mentor_id = auth.uid() or mentee_id = auth.uid()) with check (mentor_id = auth.uid() or mentee_id = auth.uid());
