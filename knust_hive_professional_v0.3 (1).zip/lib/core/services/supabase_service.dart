import 'package:supabase_flutter/supabase_flutter.dart';

/// Wraps Supabase init so main.dart stays clean and every feature
/// can reach the client the same way: `SupabaseService.client`.
class SupabaseService {
  static late final SupabaseClient client;

  static Future<void> init() async {
    await Supabase.initialize(
      url: const String.fromEnvironment('SUPABASE_URL', defaultValue: 'https://YOUR_PROJECT.supabase.co'),
      anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: 'YOUR_ANON_KEY'),
      // Offline-first: cache auth session locally so students on poor
      // network stay logged in and can view cached data.
      authFlowType: AuthFlowType.pkce,
    );
    client = Supabase.instance.client;
  }
}
