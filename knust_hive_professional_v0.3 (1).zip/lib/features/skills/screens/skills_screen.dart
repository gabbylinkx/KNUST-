import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/theme/app_theme.dart';

class SkillPath {
  final String title, tag, desc, url;
  const SkillPath(this.title, this.tag, this.desc, this.url);
}

// Curated centrally for now; move to a `skill_paths` table (see schema)
// once you want mentors/admins to add paths without a redeploy.
const skillPaths = [
  SkillPath('Intro to Programming', 'Coding', 'Python fundamentals for absolute beginners.', 'https://www.freecodecamp.org/'),
  SkillPath('Data Analysis with Excel', 'Data', 'Spreadsheets, pivot tables, dashboards.', 'https://www.coursera.org/'),
  SkillPath('Public Speaking', 'Leadership', 'Structure a talk and hold a room.', 'https://www.youtube.com/'),
  SkillPath('UI/UX Basics', 'Design', 'Wireframes, usability, and design critique.', 'https://www.figma.com/resources/learn-design/'),
  SkillPath('Starting a Side Hustle', 'Entrepreneurship', 'Validate an idea before you spend on it.', 'https://alison.com/'),
];

class SkillsScreen extends StatefulWidget {
  const SkillsScreen({super.key});

  @override
  State<SkillsScreen> createState() => _SkillsScreenState();
}

class _SkillsScreenState extends State<SkillsScreen> {
  final started = <String>{};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Skills & growth')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: skillPaths.length,
        itemBuilder: (context, i) {
          final s = skillPaths[i];
          final isStarted = started.contains(s.title);
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: IconButton(
                icon: Icon(isStarted ? Icons.check_circle : Icons.circle_outlined,
                    color: isStarted ? AppColors.forest : const Color(0xFFCBD1BE)),
                onPressed: () => setState(() => isStarted ? started.remove(s.title) : started.add(s.title)),
              ),
              title: Text(s.title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600)),
              subtitle: Text(s.desc, style: const TextStyle(fontSize: 12)),
              trailing: IconButton(
                icon: const Icon(Icons.open_in_new, size: 16, color: AppColors.forest),
                onPressed: () => launchUrl(Uri.parse(s.url), mode: LaunchMode.externalApplication),
              ),
            ),
          );
        },
      ),
    );
  }
}
