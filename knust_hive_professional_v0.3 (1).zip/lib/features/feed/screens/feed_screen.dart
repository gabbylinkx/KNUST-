import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../models/models.dart';
import '../providers/feed_provider.dart';

class FeedScreen extends ConsumerStatefulWidget {
  const FeedScreen({super.key});

  @override
  ConsumerState<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends ConsumerState<FeedScreen> {
  FeedCategory? filter;

  @override
  Widget build(BuildContext context) {
    final feedAsync = ref.watch(feedProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Campus feed')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.gold,
        foregroundColor: AppColors.forest,
        onPressed: () => _openComposer(context),
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _Chip(label: 'All', selected: filter == null, onTap: () => setState(() => filter = null)),
                ...FeedCategory.values.map((c) => Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: _Chip(
                        label: _label(c),
                        selected: filter == c,
                        onTap: () => setState(() => filter = c),
                      ),
                    )),
              ]),
            ),
          ),
          Expanded(
            child: feedAsync.when(
              data: (posts) {
                final visible = filter == null ? posts : posts.where((p) => p.category == filter).toList();
                if (visible.isEmpty) {
                  return const Center(child: Text('Nothing here yet. Be the first to post.',
                      style: TextStyle(color: Color(0xFF5B6355))));
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: visible.length,
                  itemBuilder: (ctx, i) => _PostCard(post: visible[i]),
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Couldn\'t load feed: $e')),
            ),
          ),
        ],
      ),
    );
  }

  String _label(FeedCategory c) => switch (c) {
        FeedCategory.event => 'Event',
        FeedCategory.lostFound => 'Lost & Found',
        FeedCategory.shoutout => 'Shoutout',
        FeedCategory.studyGroup => 'Study Group',
      };

  void _openComposer(BuildContext context) {
    FeedCategory cat = FeedCategory.event;
    final textCtrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
        child: StatefulBuilder(
          builder: (ctx, setSheetState) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('New post', style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 10),
              Wrap(spacing: 6, children: FeedCategory.values.map((c) => ChoiceChip(
                    label: Text(_label(c)),
                    selected: cat == c,
                    onSelected: (_) => setSheetState(() => cat = c),
                  )).toList()),
              const SizedBox(height: 10),
              TextField(controller: textCtrl, maxLines: 3, decoration: const InputDecoration(hintText: "What's happening?")),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (textCtrl.text.trim().isEmpty) return;
                    await ref.read(feedActionsProvider).post(category: cat, text: textCtrl.text.trim());
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: const Text('Post'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _Chip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => onTap());
  }
}

class _PostCard extends ConsumerWidget {
  final FeedPost post;
  const _PostCard({required this.post});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mins = DateTime.now().difference(post.ts).inMinutes;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(post.category.name, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.forest)),
                IconButton(
                  icon: const Icon(Icons.close, size: 14),
                  onPressed: () => ref.read(feedActionsProvider).delete(post.id),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(post.text, style: const TextStyle(fontSize: 13.5)),
            const SizedBox(height: 6),
            Text('${mins}m ago', style: const TextStyle(fontSize: 11, color: Color(0xFF5B6355), fontFamily: 'monospace')),
          ],
        ),
      ),
    );
  }
}
