import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../models/models.dart';
import '../campus_stops.dart';
import '../providers/shuttle_providers.dart';

class ShuttleScreen extends ConsumerStatefulWidget {
  const ShuttleScreen({super.key});

  @override
  ConsumerState<ShuttleScreen> createState() => _ShuttleScreenState();
}

class _ShuttleScreenState extends ConsumerState<ShuttleScreen> {
  String selectedStopId = greenStops.first.id;
  RidePostType boardTab = RidePostType.need;

  @override
  Widget build(BuildContext context) {
    final reportsAsync = ref.watch(shuttleReportsProvider);
    final ridesAsync = ref.watch(ridePostsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Shuttle tracker')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _RouteMapCard(
            reportsAsync: reportsAsync,
          ),
          const SizedBox(height: 16),
          _ReportBar(
            selectedStopId: selectedStopId,
            onStopChanged: (id) => setState(() => selectedStopId = id),
            onReport: () async {
              try {
                await ref.read(shuttleActionsProvider).reportSighting(
                      stopId: selectedStopId,
                      route: greenStops.any((s) => s.id == selectedStopId) ? 'green' : 'gold',
                    );
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Logged a shuttle at ${stopById(selectedStopId).name}')),
                  );
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Sign in to report a sighting')),
                  );
                }
              }
            },
          ),
          const SizedBox(height: 20),
          Text('Recent sightings', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          reportsAsync.when(
            data: (reports) {
              final fresh = reports.where((r) => r.isFresh).toList();
              if (fresh.isEmpty) {
                return const _EmptyHint('No sightings in the last 30 minutes.');
              }
              return Column(
                children: fresh.take(8).map((r) => _SightingTile(report: r)).toList(),
              );
            },
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, _) => Text('Couldn\'t load sightings: $e'),
          ),
          const SizedBox(height: 24),
          _RideBoard(
            ridesAsync: ridesAsync,
            tab: boardTab,
            onTabChanged: (t) => setState(() => boardTab = t),
          ),
        ],
      ),
    );
  }
}

class _RouteMapCard extends StatelessWidget {
  final AsyncValue<List<ShuttleReport>> reportsAsync;
  const _RouteMapCard({required this.reportsAsync});

  @override
  Widget build(BuildContext context) {
    final freshByStop = <String, ShuttleReport>{};
    reportsAsync.whenData((reports) {
      for (final r in reports.where((r) => r.isFresh)) {
        final existing = freshByStop[r.stopId];
        if (existing == null || existing.ts.isBefore(r.ts)) freshByStop[r.stopId] = r;
      }
    });

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Route map', style: Theme.of(context).textTheme.titleMedium),
                Row(children: const [
                  _LegendDot(color: AppColors.forestLight, label: 'Green'),
                  SizedBox(width: 10),
                  _LegendDot(color: AppColors.gold, label: 'Gold'),
                ]),
              ],
            ),
            const SizedBox(height: 8),
            AspectRatio(
              aspectRatio: 800 / 500,
              child: CustomPaint(
                painter: _RouteMapPainter(freshByStop: freshByStop),
                child: Container(),
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'A red pulse means someone spotted a shuttle there in the last 30 minutes.',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF5B6355)),
            ),
          ],
        ),
      ),
    );
  }
}

class _LegendDot extends StatelessWidget {
  final Color color;
  final String label;
  const _LegendDot({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 12, height: 3, color: color),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 11.5, color: Color(0xFF5B6355))),
    ]);
  }
}

/// Draws the schematic (non-GPS) transit map. Swap for a real
/// google_maps_flutter / mapbox_gl layer once live GPS is available —
/// this painter is intentionally isolated so that's a single-file change.
class _RouteMapPainter extends CustomPainter {
  final Map<String, ShuttleReport> freshByStop;
  _RouteMapPainter({required this.freshByStop});

  @override
  void paint(Canvas canvas, Size size) {
    final sx = size.width / 800;
    final sy = size.height / 500;
    Offset p(double x, double y) => Offset(x * sx, y * sy);

    final linePaint = Paint()
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(p(60, 250), p(740, 250), linePaint..color = AppColors.forestLight);
    canvas.drawLine(p(400, 50), p(400, 452), linePaint..color = AppColors.gold);

    for (final stop in {...greenStops, ...goldStops}) {
      final center = p(stop.x, stop.y);
      final r = stop.isHub ? 11.0 : 7.5;
      final fresh = freshByStop[stop.id];

      if (fresh != null) {
        canvas.drawCircle(center, r + 10, Paint()..color = AppColors.clay.withOpacity(0.16));
      }
      canvas.drawCircle(
        center,
        r,
        Paint()..color = stop.isHub ? AppColors.ink : Colors.white,
      );
      canvas.drawCircle(
        center,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = stop.isHub ? 3 : 2.5
          ..color = stop.isHub ? AppColors.gold : AppColors.forest,
      );
      if (fresh != null) {
        canvas.drawCircle(center, 3, Paint()..color = AppColors.clay);
      }

      final tp = TextPainter(
        text: TextSpan(
          text: stop.name,
          style: TextStyle(
            fontSize: stop.isHub ? 12 : 10.5,
            fontWeight: stop.isHub ? FontWeight.w700 : FontWeight.w500,
            color: AppColors.ink,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      final labelOffset = greenStops.contains(stop)
          ? Offset(center.dx - tp.width / 2, center.dy - r - tp.height - 4)
          : Offset(center.dx + r + 4, center.dy - tp.height / 2);
      tp.paint(canvas, labelOffset);
    }
  }

  @override
  bool shouldRepaint(covariant _RouteMapPainter oldDelegate) =>
      oldDelegate.freshByStop.length != freshByStop.length;
}

class _ReportBar extends StatelessWidget {
  final String selectedStopId;
  final ValueChanged<String> onStopChanged;
  final VoidCallback onReport;
  const _ReportBar({required this.selectedStopId, required this.onStopChanged, required this.onReport});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AppColors.forest, borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          const Icon(Icons.place, color: AppColors.gold, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selectedStopId,
                isExpanded: true,
                dropdownColor: Colors.white,
                items: allStops
                    .map((s) => DropdownMenuItem(value: s.id, child: Text(s.name)))
                    .toList(),
                onChanged: (v) => v != null ? onStopChanged(v) : null,
              ),
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton.icon(
            onPressed: onReport,
            icon: const Icon(Icons.near_me, size: 16),
            label: const Text('Report'),
          ),
        ],
      ),
    );
  }
}

class _SightingTile extends StatelessWidget {
  final ShuttleReport report;
  const _SightingTile({required this.report});

  @override
  Widget build(BuildContext context) {
    final mins = DateTime.now().difference(report.ts).inMinutes;
    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      child: ListTile(
        dense: true,
        leading: const Icon(Icons.directions_bus, color: AppColors.forest, size: 18),
        title: Text(stopById(report.stopId).name),
        trailing: Text(mins < 1 ? 'just now' : '${mins}m ago',
            style: const TextStyle(fontFamily: 'monospace', fontSize: 11.5, color: Color(0xFF5B6355))),
      ),
    );
  }
}

class _RideBoard extends ConsumerWidget {
  final AsyncValue<List<RidePost>> ridesAsync;
  final RidePostType tab;
  final ValueChanged<RidePostType> onTabChanged;
  const _RideBoard({required this.ridesAsync, required this.tab, required this.onTabChanged});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Ride board', style: Theme.of(context).textTheme.titleMedium),
                TextButton.icon(
                  onPressed: () => _showPostSheet(context, ref, tab),
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Post'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: _TabChip(
                  label: 'Need a ride',
                  selected: tab == RidePostType.need,
                  onTap: () => onTabChanged(RidePostType.need),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _TabChip(
                  label: 'Offering space',
                  selected: tab == RidePostType.offer,
                  onTap: () => onTabChanged(RidePostType.offer),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            ridesAsync.when(
              data: (rides) {
                final visible = rides.where((p) => p.type == tab).toList();
                if (visible.isEmpty) return const _EmptyHint('Nothing posted yet.');
                return Column(
                  children: visible.map((p) => _RidePostTile(post: p)).toList(),
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Text('Couldn\'t load ride board: $e'),
            ),
          ],
        ),
      ),
    );
  }

  void _showPostSheet(BuildContext context, WidgetRef ref, RidePostType type) {
    String from = greenStops.first.id;
    String to = hub.id;
    final timeCtrl = TextEditingController();
    final noteCtrl = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
        ),
        child: StatefulBuilder(
          builder: (ctx, setSheetState) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(type == RidePostType.need ? 'Need a ride' : 'Offer space',
                  style: Theme.of(ctx).textTheme.titleMedium),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: from,
                    items: allStops.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))).toList(),
                    onChanged: (v) => setSheetState(() => from = v ?? from),
                  ),
                ),
                const Padding(padding: EdgeInsets.symmetric(horizontal: 6), child: Icon(Icons.arrow_forward, size: 16)),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: to,
                    items: allStops.map((s) => DropdownMenuItem(value: s.id, child: Text(s.name))).toList(),
                    onChanged: (v) => setSheetState(() => to = v ?? to),
                  ),
                ),
              ]),
              const SizedBox(height: 8),
              TextField(controller: timeCtrl, decoration: const InputDecoration(hintText: 'When? e.g. Today 4:30pm')),
              const SizedBox(height: 8),
              TextField(controller: noteCtrl, decoration: const InputDecoration(hintText: 'Note (optional)')),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    if (timeCtrl.text.trim().isEmpty) return;
                    await ref.read(shuttleActionsProvider).postRide(
                          type: type,
                          fromStopId: from,
                          toStopId: to,
                          time: timeCtrl.text.trim(),
                          note: noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
                        );
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: const Text('Post to board'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TabChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _TabChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? AppColors.forest : Colors.white,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: selected ? AppColors.forest : AppColors.paperDim, width: 1.5),
        ),
        child: Text(label,
            style: TextStyle(
                fontSize: 12.5, fontWeight: FontWeight.w600, color: selected ? Colors.white : AppColors.ink)),
      ),
    );
  }
}

class _RidePostTile extends ConsumerWidget {
  final RidePost post;
  const _RidePostTile({required this.post});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mins = DateTime.now().difference(post.ts).inMinutes;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text('${stopById(post.fromStopId).name}  →  ${stopById(post.toStopId).name}',
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 15),
                  onPressed: () => ref.read(shuttleActionsProvider).deleteRidePost(post.id),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Wrap(spacing: 10, children: [
              Text(post.time, style: const TextStyle(fontSize: 12, color: Color(0xFF5B6355))),
              Text('${mins}m ago', style: const TextStyle(fontSize: 11, fontFamily: 'monospace', color: Color(0xFF5B6355))),
            ]),
            if (post.note != null) Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(post.note!, style: const TextStyle(fontSize: 12.5)),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyHint extends StatelessWidget {
  final String text;
  const _EmptyHint(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.paperDim, style: BorderStyle.solid),
        borderRadius: BorderRadius.circular(12),
      ),
      alignment: Alignment.center,
      child: Text(text, style: const TextStyle(fontSize: 13, color: Color(0xFF5B6355))),
    );
  }
}
