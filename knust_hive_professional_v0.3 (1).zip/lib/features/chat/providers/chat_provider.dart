import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/services/supabase_service.dart';

class ChatSummary {
  final String id;
  final String? name;
  final bool isGroup;
  final bool isAnonymousWall;
  final DateTime createdAt;

  const ChatSummary({
    required this.id,
    this.name,
    required this.isGroup,
    required this.isAnonymousWall,
    required this.createdAt,
  });

  factory ChatSummary.fromMap(Map<String, dynamic> m) => ChatSummary(
        id: m['id'] as String,
        name: m['name'] as String?,
        isGroup: m['is_group'] as bool? ?? false,
        isAnonymousWall: m['is_anonymous_wall'] as bool? ?? false,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class ChatMessage {
  final String id;
  final String chatId;
  final String senderId;
  final String text;
  final bool flagged;
  final DateTime createdAt;

  const ChatMessage({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.text,
    required this.flagged,
    required this.createdAt,
  });

  factory ChatMessage.fromMap(Map<String, dynamic> m) => ChatMessage(
        id: m['id'] as String,
        chatId: m['chat_id'] as String,
        senderId: m['sender_id'] as String,
        text: m['text'] as String,
        flagged: m['flagged'] as bool? ?? false,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

final chatListProvider = FutureProvider<List<ChatSummary>>((ref) async {
  final client = SupabaseService.client;
  final userId = client.auth.currentUser?.id;
  if (userId == null) return const [];

  final rows = await client
      .from('chat_members')
      .select('chat_id, chats(id, name, is_group, is_anonymous_wall, created_at)')
      .eq('user_id', userId);

  return rows
      .map((row) {
        final chat = row['chats'];
        return chat is Map<String, dynamic>
            ? ChatSummary.fromMap(chat)
            : null;
      })
      .whereType<ChatSummary>()
      .toList();
});

final chatMessagesProvider =
    StreamProvider.family<List<ChatMessage>, String>((ref, chatId) {
  return SupabaseService.client
      .from('messages')
      .stream(primaryKey: ['id'])
      .eq('chat_id', chatId)
      .order('created_at', ascending: true)
      .map((rows) => rows.map(ChatMessage.fromMap).toList());
});

class ChatActions {
  final SupabaseClient _client = SupabaseService.client;

  String? get currentUserId => _client.auth.currentUser?.id;

  Future<List<Map<String, dynamic>>> loadStudents() async {
    final me = currentUserId;
    if (me == null) return const [];
    final rows = await _client
        .from('profiles')
        .select('id, display_name, student_id')
        .neq('id', me)
        .order('display_name')
        .limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<String> createDirectChat(String otherUserId) async {
    final result = await _client.rpc(
      'create_direct_chat',
      params: {'other_user_id': otherUserId},
    );
    return result as String;
  }

  Future<void> sendMessage({
    required String chatId,
    required String text,
  }) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw StateError('Sign in to send messages');

    final value = text.trim();
    if (value.isEmpty) return;

    await _client.from('messages').insert({
      'chat_id': chatId,
      'sender_id': userId,
      'text': value,
    });
  }
}

final chatActionsProvider = Provider((ref) => ChatActions());
