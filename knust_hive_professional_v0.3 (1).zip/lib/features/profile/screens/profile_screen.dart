import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/services/supabase_service.dart';
import '../../../core/theme/app_theme.dart';
import '../../auth/providers/auth_provider.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = SupabaseService.client.auth.currentUser;
    final metadata = user?.userMetadata ?? const <String, dynamic>{};
    final name = metadata['display_name'] as String? ?? 'KNUST Student';
    final initials = name.trim().isEmpty ? 'K' : name.trim().split(RegExp(r'\s+')).take(2).map((e) => e[0]).join().toUpperCase();

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(children: [
                CircleAvatar(radius: 31, backgroundColor: AppColors.forest, child: Text(initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20))),
                const SizedBox(width: 15),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Text(user?.email ?? 'Signed in', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                ])),
                IconButton(onPressed: () {}, icon: const Icon(Icons.edit_outlined)),
              ]),
            ),
          ),
          const SizedBox(height: 20),
          const _SectionTitle('Student profile'),
          _SettingTile(icon: Icons.school_outlined, title: 'Faculty & department', subtitle: 'Add your academic details'),
          _SettingTile(icon: Icons.badge_outlined, title: 'Student ID', subtitle: 'Keep your verified identity private'),
          _SettingTile(icon: Icons.interests_outlined, title: 'Interests & skills', subtitle: 'Improve recommendations'),
          const SizedBox(height: 18),
          const _SectionTitle('Preferences'),
          _SettingTile(icon: Icons.notifications_none, title: 'Notifications', subtitle: 'Announcements, messages and alerts'),
          _SettingTile(icon: Icons.dark_mode_outlined, title: 'Appearance', subtitle: 'Use system light/dark mode'),
          const SizedBox(height: 18),
          const _SectionTitle('Safety & support'),
          _SettingTile(icon: Icons.shield_outlined, title: 'Privacy & safety', subtitle: 'Manage your account and content'),
          _SettingTile(icon: Icons.help_outline, title: 'Help & feedback', subtitle: 'Tell us how to make Hive better'),
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: () => ref.read(authActionsProvider).signOut(),
            icon: const Icon(Icons.logout, color: AppColors.clay),
            label: const Text('Sign out', style: TextStyle(color: AppColors.clay)),
          ),
          const SizedBox(height: 18),
          const Center(child: Text('KNUST Hive • v0.2.0', style: TextStyle(color: AppColors.muted, fontSize: 11))),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(left: 4, bottom: 8), child: Text(text.toUpperCase(), style: const TextStyle(fontSize: 10.5, letterSpacing: .8, fontWeight: FontWeight.w800, color: AppColors.muted)));
}

class _SettingTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const _SettingTile({required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 3),
          leading: Container(width: 40, height: 40, decoration: BoxDecoration(color: AppColors.paper, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: AppColors.forest, size: 20)),
          title: Text(title, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w650)),
          subtitle: Text(subtitle, style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
          trailing: const Icon(Icons.chevron_right, color: AppColors.muted),
        ),
      );
}
