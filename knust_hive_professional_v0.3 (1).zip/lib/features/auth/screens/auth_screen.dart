import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../providers/auth_provider.dart';

class AuthScreen extends ConsumerStatefulWidget {
  const AuthScreen({super.key});

  @override
  ConsumerState<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends ConsumerState<AuthScreen> {
  bool isSignUp = false;
  final emailCtrl = TextEditingController();
  final passwordCtrl = TextEditingController();
  final studentIdCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> _submit() async {
    setState(() { loading = true; error = null; });
    try {
      final auth = ref.read(authActionsProvider);
      if (isSignUp) {
        await auth.signUpWithStudentId(
          email: emailCtrl.text.trim(),
          password: passwordCtrl.text,
          studentId: studentIdCtrl.text.trim(),
          displayName: nameCtrl.text.trim(),
        );
      } else {
        await auth.signIn(email: emailCtrl.text.trim(), password: passwordCtrl.text);
      }
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.forest,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.hive_rounded, color: AppColors.gold, size: 44),
              const SizedBox(height: 10),
              Text('KNUST Hive', textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.displaySmall?.copyWith(color: Colors.white)),
              const SizedBox(height: 4),
              const Text('Your campus, in one place', textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.goldSoft)),
              const SizedBox(height: 32),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    if (isSignUp) ...[
                      TextField(controller: nameCtrl, decoration: const InputDecoration(hintText: 'Full name')),
                      const SizedBox(height: 10),
                      TextField(controller: studentIdCtrl, decoration: const InputDecoration(hintText: 'Student ID')),
                      const SizedBox(height: 10),
                    ],
                    TextField(controller: emailCtrl, decoration: const InputDecoration(hintText: 'Email'),
                        keyboardType: TextInputType.emailAddress),
                    const SizedBox(height: 10),
                    TextField(controller: passwordCtrl, decoration: const InputDecoration(hintText: 'Password'),
                        obscureText: true),
                    if (error != null) Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(error!, style: const TextStyle(color: AppColors.clay, fontSize: 12)),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: loading ? null : _submit,
                        child: loading
                            ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : Text(isSignUp ? 'Create account' : 'Sign in'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: () => ref.read(authActionsProvider).signInWithGoogle(),
                      icon: const Icon(Icons.g_mobiledata),
                      label: const Text('Continue with Google'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              TextButton(
                onPressed: () => setState(() => isSignUp = !isSignUp),
                child: Text(
                  isSignUp ? 'Already have an account? Sign in' : "New here? Create an account",
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
