import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/services/supabase_service.dart';

/// Streams auth state so the router (see core/router/app_router.dart) can
/// redirect signed-out users to /auth without polling.
final authStateProvider = StreamProvider<AuthState>((ref) {
  return SupabaseService.client.auth.onAuthStateChange;
});

class AuthActions {
  final _client = SupabaseService.client;

  Future<void> signIn({required String email, required String password}) async {
    await _client.auth.signInWithPassword(email: email, password: password);
  }

  /// Student ID is verified server-side by a Postgres trigger that checks
  /// it against the `verified_student_ids` table (uploaded each semester
  /// by the registrar's office) before the profile row is allowed to
  /// exist — see supabase/schema.sql for the trigger definition.
  Future<void> signUpWithStudentId({
    required String email,
    required String password,
    required String studentId,
    required String displayName,
  }) async {
    final res = await _client.auth.signUp(email: email, password: password);
    final userId = res.user?.id;
    if (userId == null) throw StateError('Sign up did not return a user');
    await _client.from('profiles').insert({
      'id': userId,
      'student_id': studentId,
      'display_name': displayName,
    });
  }

  Future<void> signInWithGoogle() async {
    await _client.auth.signInWithOAuth(OAuthProvider.google);
  }

  Future<void> signOut() => _client.auth.signOut();
}

final authActionsProvider = Provider((ref) => AuthActions());
