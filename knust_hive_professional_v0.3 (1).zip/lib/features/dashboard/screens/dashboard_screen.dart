import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../../shuttle/providers/shuttle_providers.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final now = DateTime.now();
    final greeting = now.hour < 12 ? 'Good morning' : now.hour < 17 ? 'Good afternoon' : 'Good evening';
    final reportsAsync = ref.watch(shuttleReportsProvider);
    final ridesAsync = ref.watch(ridePostsProvider);

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 20,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('KNUST Hive', style: TextStyle(fontWeight: FontWeight.w800)),
            Text('Your campus, connected.', style: TextStyle(fontSize: 11, color: AppColors.muted)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Profile',
            onPressed: () => context.push('/profile'),
            icon: const CircleAvatar(
              radius: 17,
              backgroundColor: AppColors.forest,
              child: Icon(Icons.person, size: 18, color: Colors.white),
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(shuttleReportsProvider);
          ref.invalidate(ridePostsProvider);
          await Future<void>.delayed(const Duration(milliseconds: 250));
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          children: [
            Text(greeting, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 2),
            Text(DateFormat('EEEE, MMMM d').format(now), style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            const SizedBox(height: 18),
            _AnnouncementCard(),
            const SizedBox(height: 18),
            Text('Campus at a glance', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _StatCard(
                label: 'Live shuttle reports',
                value: reportsAsync.valueOrNull?.where((x) => x.isFresh).length.toString() ?? '—',
                icon: Icons.directions_bus_filled,
              )),
              const SizedBox(width: 10),
              Expanded(child: _StatCard(
                label: 'Open ride posts',
                value: ridesAsync.valueOrNull?.length.toString() ?? '—',
                icon: Icons.people_alt,
              )),
            ]),
            const SizedBox(height: 22),
            Text('Your day', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            const _EmptyScheduleCard(),
            const SizedBox(height: 22),
            Text('Quick access', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            const Row(children: [
              Expanded(child: _QuickAction(icon: Icons.directions_bus, label: 'Shuttle')),
              SizedBox(width: 10),
              Expanded(child: _QuickAction(icon: Icons.campaign, label: 'Campus feed')),
              SizedBox(width: 10),
              Expanded(child: _QuickAction(icon: Icons.auto_awesome, label: 'Skills')),
            ]),
            const SizedBox(height: 22),
            const _ProductNote(),
          ],
        ),
      ),
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [AppColors.forest, AppColors.forestLight]),
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: Color(0x33FFFFFF),
            child: Icon(Icons.campaign, color: AppColors.gold),
          ),
          SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Campus update', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
            SizedBox(height: 5),
            Text('Stay updated with important campus announcements, events and student opportunities.', style: TextStyle(color: AppColors.goldSoft, height: 1.35, fontSize: 13)),
          ])),
        ]),
      );
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  const _StatCard({required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(color: AppColors.gold.withOpacity(.18), borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: AppColors.forest, size: 20),
            ),
            const SizedBox(height: 12),
            Text(value, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 11.5)),
          ]),
        ),
      );
}

class _EmptyScheduleCard extends StatelessWidget {
  const _EmptyScheduleCard();
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: AppColors.paper, borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.calendar_month_outlined, color: AppColors.forest),
            ),
            const SizedBox(width: 13),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('No timetable added yet', style: TextStyle(fontWeight: FontWeight.w700)),
              SizedBox(height: 3),
              Text('Your classes and deadlines will appear here.', style: TextStyle(color: AppColors.muted, fontSize: 12)),
            ])),
            const Icon(Icons.chevron_right, color: AppColors.muted),
          ]),
        ),
      );
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  const _QuickAction({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 15),
          child: Column(children: [
            Icon(icon, color: AppColors.forest),
            const SizedBox(height: 7),
            Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600)),
          ]),
        ),
      );
}

class _ProductNote extends StatelessWidget {
  const _ProductNote();
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: AppColors.gold.withOpacity(.13), borderRadius: BorderRadius.circular(16)),
        child: const Row(children: [
          Icon(Icons.auto_awesome, color: AppColors.forest),
          SizedBox(width: 10),
          Expanded(child: Text('Hive is being built around the real needs of KNUST students — academics, mobility, community and career growth.', style: TextStyle(fontSize: 12.5, height: 1.35))),
        ]),
      );
}
